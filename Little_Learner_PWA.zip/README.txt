LITTLE LEARNER — iPHONE WEB APP VERSION

This version includes:
- Home Screen app manifest
- Standalone app mode
- Little Learner app icon
- Offline caching/service worker
- Animals, Colors, Numbers and ABC
- Tap-to-speak learning

HOW TO INSTALL ON IPHONE:
1. The files must be hosted at an HTTPS web address.
2. Open that address in Safari.
3. Tap Share.
4. Tap Add to Home Screen.
5. Turn ON “Open as Web App”.
6. Tap Add.

Apple documents this Home Screen web-app flow here:
https://support.apple.com/en-ca/guide/iphone/iphea86e5236/ios

IMPORTANT:
A local ZIP/HTML file opened from the Files app cannot be converted into a Home Screen web app. It needs to be served as a website.

Next step: publish this folder to a simple HTTPS host. Once you give me the hosting method you prefer, I can guide you through the exact iPhone steps.
